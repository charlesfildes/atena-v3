package com.orion.chat.data.repository

import com.orion.chat.data.api.DeepSeekService
import com.orion.chat.data.local.ChatDao
import com.orion.chat.data.local.ChatMessageEntity
import com.orion.chat.data.local.ChatPreferences
import com.orion.chat.data.model.ApiMessage
import com.orion.chat.data.model.ChatCompletionRequest
import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.ChatRole
import com.orion.chat.data.model.StreamEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ChatRepository(
    private val apiService: DeepSeekService,
    private val chatDao: ChatDao,
    val preferences: ChatPreferences
) {
    val messagesFlow: Flow<List<ChatMessage>> = chatDao.getAllMessagesFlow()
        .map { entities -> entities.map { it.toChatMessage() } }

    suspend fun saveMessage(message: ChatMessage) = withContext(Dispatchers.IO) {
        chatDao.insertMessage(ChatMessageEntity.fromChatMessage(message))
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        chatDao.clearAllMessages()
    }

    suspend fun deleteMessage(id: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(id)
    }

    /**
     * Builds history context and calls DeepSeek SSE streaming endpoint.
     */
    suspend fun streamChat(
        userPrompt: String,
        modelOverride: String? = null
    ): Flow<StreamEvent> = withContext(Dispatchers.IO) {
        val apiKey = preferences.getApiKey()
        val model = modelOverride ?: preferences.getSelectedModel()
        val systemPrompt = preferences.getSystemPrompt()
        val temperature = preferences.getTemperature().toDouble()

        // Build conversation context from recent messages in local history
        val recentMessages = chatDao.getAllMessages()
        val apiMessages = mutableListOf<ApiMessage>()

        if (systemPrompt.isNotBlank()) {
            apiMessages.add(ApiMessage(role = "system", content = systemPrompt))
        }

        // Add last 10 messages for context continuity
        val historyWindow = recentMessages.takeLast(10)
        for (entity in historyWindow) {
            if (entity.role == ChatRole.USER.value || entity.role == ChatRole.ASSISTANT.value) {
                if (entity.content.isNotBlank()) {
                    apiMessages.add(ApiMessage(role = entity.role, content = entity.content))
                }
            }
        }

        // Add the current prompt if not already the last message in history
        if (apiMessages.lastOrNull()?.content != userPrompt) {
            apiMessages.add(ApiMessage(role = "user", content = userPrompt))
        }

        val request = ChatCompletionRequest(
            model = model,
            messages = apiMessages,
            stream = true,
            temperature = if (model.contains("reasoner")) null else temperature, // DeepSeek R1 prefers default temperature
            maxTokens = 4096
        )

        apiService.streamChatCompletion(apiKey = apiKey, requestBody = request)
    }
}
