package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.orion.chat.ui.screens.ChatScreen
import com.orion.chat.ui.theme.OrionAtenaTheme
import com.orion.chat.ui.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OrionAtenaTheme {
                val viewModel: ChatViewModel = viewModel(
                    factory = ChatViewModel.Factory(application)
                )
                val uiState = viewModel.uiState.collectAsStateWithLifecycle().value

                ChatScreen(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}
