package com.orion.chat.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.ChatRole
import com.orion.chat.data.model.MessageStatus
import com.orion.chat.ui.theme.AssistantBubbleBackground
import com.orion.chat.ui.theme.AssistantBubbleBorder
import com.orion.chat.ui.theme.AtenaCyanPrimary
import com.orion.chat.ui.theme.AtenaIndigo
import com.orion.chat.ui.theme.AtenaViolet
import com.orion.chat.ui.theme.ReasoningBackground
import com.orion.chat.ui.theme.StatusError
import com.orion.chat.ui.theme.UserBubbleBackground
import com.orion.chat.ui.theme.UserBubbleBorder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    isStreaming: Boolean = false,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == ChatRole.USER
    val context = LocalContext.current
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(if (isUser) "user_message_item" else "assistant_message_item"),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            // Atena Orion Avatar
            AtenaAvatar()
            Spacer(modifier = Modifier.width(10.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 320.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            // Header for assistant (Model badge)
            if (!isUser) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
                ) {
                    Text(
                        text = "Atena",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = AtenaCyanPrimary
                    )
                    if (message.model != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AtenaIndigo.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AtenaIndigo.copy(alpha = 0.4f)),
                            modifier = Modifier.padding(vertical = 1.dp)
                        ) {
                            Text(
                                text = message.model,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = AtenaCyanPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Reasoning Box (DeepSeek Reasoner / R1 CoT)
            if (!message.reasoningContent.isNullOrBlank()) {
                ReasoningAccordion(
                    reasoningText = message.reasoningContent,
                    isStreamingReasoning = isStreaming && message.content.isBlank()
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Main Message Bubble
            Surface(
                shape = RoundedCornerShape(
                    topStart = 18.dp,
                    topEnd = 18.dp,
                    bottomStart = if (isUser) 18.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 18.dp
                ),
                color = if (isUser) UserBubbleBackground else AssistantBubbleBackground,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isUser) UserBubbleBorder else AssistantBubbleBorder
                ),
                tonalElevation = if (isUser) 2.dp else 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    if (message.content.isNotBlank()) {
                        FormattedChatText(
                            text = message.content,
                            isUser = isUser,
                            onCopyCode = { codeSnippet ->
                                copyToClipboard(context, codeSnippet, "Código copiado!")
                            }
                        )
                    } else if (isStreaming) {
                        TypingIndicator(
                            dotColor = AtenaCyanPrimary,
                            label = if (message.reasoningContent.isNullOrBlank()) "Atena está formulando resposta..." else "Processando raciocínio..."
                        )
                    }

                    // Error state banner inside message
                    if (message.status == MessageStatus.ERROR || message.errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(StatusError.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .border(1.dp, StatusError.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "Erro",
                                tint = StatusError,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = message.errorMessage ?: "Falha ao gerar resposta.",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                color = StatusError,
                                modifier = Modifier.weight(1f)
                            )
                            if (onRetry != null) {
                                IconButton(
                                    onClick = onRetry,
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Tentar novamente",
                                        tint = StatusError,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Bottom info bar (timestamp + copy button)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )

                        if (message.content.isNotBlank() && !isStreaming) {
                            IconButton(
                                onClick = {
                                    copyToClipboard(context, message.content, "Mensagem copiada!")
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copiar mensagem",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(10.dp))
            UserAvatar()
        }
    }
}

@Composable
fun AtenaAvatar() {
    Box(
        modifier = Modifier
            .size(36.dp)
            .background(
                brush = Brush.linearGradient(
                    listOf(AtenaCyanPrimary, AtenaIndigo, AtenaViolet)
                ),
                shape = CircleShape
            )
            .border(1.5.dp, AtenaCyanPrimary.copy(alpha = 0.8f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "Atena Avatar",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun UserAvatar() {
    Box(
        modifier = Modifier
            .size(36.dp)
            .background(
                brush = Brush.linearGradient(
                    listOf(Color(0xFF334155), Color(0xFF1E293B))
                ),
                shape = CircleShape
            )
            .border(1.5.dp, AtenaIndigo.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "Usuário",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun ReasoningAccordion(
    reasoningText: String,
    isStreamingReasoning: Boolean,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(isStreamingReasoning) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = ReasoningBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, AtenaViolet.copy(alpha = 0.35f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = AtenaViolet,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isStreamingReasoning) "Raciocinando (DeepSeek R1)..." else "Processo de Raciocínio",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = AtenaViolet
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Recolher" else "Expandir",
                    tint = AtenaViolet,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp, bottom = 4.dp)) {
                    Text(
                        text = reasoningText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 12.5.sp,
                            lineHeight = 18.sp,
                            fontFamily = FontFamily.SansSerif
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}

@Composable
fun FormattedChatText(
    text: String,
    isUser: Boolean,
    onCopyCode: (String) -> Unit
) {
    // Simple robust markdown & code block splitter
    val segments = remember(text) { parseMarkdownSegments(text) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (segment in segments) {
            when (segment) {
                is TextSegment.Plain -> {
                    Text(
                        text = segment.content,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 14.5.sp,
                            lineHeight = 21.sp
                        ),
                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
                is TextSegment.CodeBlock -> {
                    CodeBlockView(
                        language = segment.language,
                        code = segment.code,
                        onCopy = { onCopyCode(segment.code) }
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockView(
    language: String,
    code: String,
    onCopy: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF090D16),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            // Code header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131A29))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "CODE" }.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                    color = AtenaCyanPrimary
                )
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copiar Código",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            // Code content
            Text(
                text = code,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.5.sp,
                    lineHeight = 17.sp
                ),
                color = Color(0xFFE2E8F0),
                modifier = Modifier.padding(10.dp)
            )
        }
    }
}

sealed class TextSegment {
    data class Plain(val content: String) : TextSegment()
    data class CodeBlock(val language: String, val code: String) : TextSegment()
}

fun parseMarkdownSegments(raw: String): List<TextSegment> {
    val results = mutableListOf<TextSegment>()
    val codeFenceRegex = "```([a-zA-Z0-9_-]*)\\n?([\\s\\S]*?)```".toRegex()
    var lastIndex = 0

    val matches = codeFenceRegex.findAll(raw)
    for (match in matches) {
        val plainBefore = raw.substring(lastIndex, match.range.first)
        if (plainBefore.isNotBlank()) {
            results.add(TextSegment.Plain(plainBefore.trim()))
        }
        val language = match.groupValues[1]
        val code = match.groupValues[2]
        results.add(TextSegment.CodeBlock(language = language, code = code.trimEnd()))
        lastIndex = match.range.last + 1
    }

    if (lastIndex < raw.length) {
        val remaining = raw.substring(lastIndex)
        if (remaining.isNotBlank()) {
            results.add(TextSegment.Plain(remaining.trim()))
        }
    }

    return if (results.isEmpty()) listOf(TextSegment.Plain(raw)) else results
}

private fun copyToClipboard(context: Context, text: String, toastMessage: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Atena Orion", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
}
