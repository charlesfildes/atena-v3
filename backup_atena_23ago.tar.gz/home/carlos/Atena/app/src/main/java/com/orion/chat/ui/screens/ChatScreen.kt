package com.orion.chat.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.ChatRole
import com.orion.chat.data.model.MessageStatus
import com.orion.chat.ui.components.ChatInputBar
import com.orion.chat.ui.components.ChatMessageItem
import com.orion.chat.ui.components.EmptyChatHero
import com.orion.chat.ui.components.SettingsDialog
import com.orion.chat.ui.state.ChatUiState
import com.orion.chat.ui.state.StreamingState
import com.orion.chat.ui.theme.AtenaCyanPrimary
import com.orion.chat.ui.theme.AtenaIndigo
import com.orion.chat.ui.theme.AtenaViolet
import com.orion.chat.ui.theme.OrionDarkBackground
import com.orion.chat.ui.theme.OrionDarkBorder
import com.orion.chat.ui.theme.OrionDarkSurface
import com.orion.chat.ui.theme.StatusError
import com.orion.chat.ui.theme.StatusSuccess
import com.orion.chat.ui.theme.StatusWarning
import com.orion.chat.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    uiState: ChatUiState,
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Determine if we should show active streaming message item
    val activeStreamingMessage = remember(uiState.streamingState, uiState.currentStreamingMessageId) {
        when (val state = uiState.streamingState) {
            is StreamingState.Loading -> {
                ChatMessage(
                    id = uiState.currentStreamingMessageId ?: "streaming_preview",
                    role = ChatRole.ASSISTANT,
                    content = "",
                    reasoningContent = null,
                    status = MessageStatus.STREAMING,
                    model = uiState.selectedModel.displayName
                )
            }
            is StreamingState.Streaming -> {
                ChatMessage(
                    id = uiState.currentStreamingMessageId ?: "streaming_preview",
                    role = ChatRole.ASSISTANT,
                    content = state.partialContent,
                    reasoningContent = state.reasoningContent,
                    status = MessageStatus.STREAMING,
                    model = uiState.selectedModel.displayName
                )
            }
            else -> null
        }
    }

    // Combine persisted messages with active streaming message
    val displayMessages = remember(uiState.messages, activeStreamingMessage) {
        if (activeStreamingMessage != null) {
            uiState.messages + activeStreamingMessage
        } else {
            uiState.messages
        }
    }

    // Auto-scroll when messages update or streaming chunk arrives
    LaunchedEffect(displayMessages.size, (uiState.streamingState as? StreamingState.Streaming)?.partialContent?.length) {
        if (displayMessages.isNotEmpty()) {
            listState.animateScrollToItem(displayMessages.size - 1)
        }
    }

    val showScrollToBottom by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex < (displayMessages.size - 3).coerceAtLeast(0)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(OrionDarkBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Orion Glowing Icon
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        listOf(AtenaCyanPrimary, AtenaIndigo, AtenaViolet)
                                    ),
                                    shape = CircleShape
                                )
                                .border(1.dp, AtenaCyanPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Atena",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• Orion",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AtenaCyanPrimary
                                )
                            }
                            // Model selector chip
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { viewModel.setShowSettingsDialog(true) }
                            ) {
                                Text(
                                    text = uiState.selectedModel.displayName,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(
                                            if (uiState.isApiKeyConfigured) StatusSuccess else StatusWarning,
                                            CircleShape
                                        )
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Clear history button
                    if (uiState.messages.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.setShowClearConfirmDialog(true) },
                            modifier = Modifier.testTag("clear_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Limpar conversa",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Settings button
                    IconButton(
                        onClick = { viewModel.setShowSettingsDialog(true) },
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Configurações",
                            tint = if (uiState.isApiKeyConfigured) MaterialTheme.colorScheme.onSurfaceVariant else StatusWarning
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrionDarkSurface,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            Column {
                // Error banner if any
                val streamingState = uiState.streamingState
                if (streamingState is StreamingState.Error) {
                    Surface(
                        color = StatusError.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusError.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = StatusError,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = streamingState.message,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = StatusError,
                                    maxLines = 2
                                )
                            }
                            if (streamingState.canRetry) {
                                TextButton(onClick = { viewModel.retryLastMessage() }) {
                                    Text(
                                        text = "Tentar",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AtenaCyanPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                // API Key Missing Hint Banner
                if (!uiState.isApiKeyConfigured) {
                    Surface(
                        color = StatusWarning.copy(alpha = 0.15f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setShowSettingsDialog(true) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "⚠️ Chave DeepSeek não configurada. Toque aqui para adicionar.",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = StatusWarning
                            )
                        }
                    }
                }

                // Chat Input Bar
                ChatInputBar(
                    prompt = uiState.inputPrompt,
                    onPromptChange = { viewModel.onInputPromptChange(it) },
                    onSend = { viewModel.sendMessage() },
                    onStop = { viewModel.stopStreaming() },
                    isStreaming = uiState.isStreaming
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(OrionDarkBackground)
        ) {
            if (displayMessages.isEmpty()) {
                EmptyChatHero(
                    onSelectPrompt = { selectedPrompt ->
                        viewModel.onInputPromptChange(selectedPrompt)
                        viewModel.sendMessage(selectedPrompt)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(top = 10.dp, bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(
                        items = displayMessages,
                        key = { it.id }
                    ) { message ->
                        val isThisMessageStreaming = message.status == MessageStatus.STREAMING
                        ChatMessageItem(
                            message = message,
                            isStreaming = isThisMessageStreaming,
                            onRetry = if (message.status == MessageStatus.ERROR) {
                                { viewModel.retryLastMessage() }
                            } else null
                        )
                    }
                }
            }

            // Scroll to bottom floating button
            AnimatedVisibility(
                visible = showScrollToBottom,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                FloatingActionButton(
                    onClick = {
                        scope.launch {
                            if (displayMessages.isNotEmpty()) {
                                listState.animateScrollToItem(displayMessages.size - 1)
                            }
                        }
                    },
                    containerColor = OrionDarkSurface,
                    contentColor = AtenaCyanPrimary,
                    modifier = Modifier
                        .size(40.dp)
                        .border(1.dp, AtenaCyanPrimary.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Rolar para o fim",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }

    // Settings Dialog
    if (uiState.showSettingsDialog) {
        SettingsDialog(
            currentApiKey = uiState.apiKey,
            currentModel = uiState.selectedModel,
            currentTemperature = uiState.temperature,
            currentSystemPrompt = uiState.systemPrompt,
            onSave = { apiKey, model, temp, prompt ->
                viewModel.setApiKey(apiKey)
                viewModel.setSelectedModel(model)
                viewModel.setTemperature(temp)
                viewModel.setSystemPrompt(prompt)
                viewModel.dismissError()
            },
            onDismiss = { viewModel.setShowSettingsDialog(false) }
        )
    }

    // Clear History Confirmation Dialog
    if (uiState.showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowClearConfirmDialog(false) },
            title = {
                Text(
                    text = "Limpar Conversa?",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "Todas as mensagens da conversa atual serão excluídas permanentemente do dispositivo.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.clearChat() }
                ) {
                    Text("Limpar", color = StatusError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowClearConfirmDialog(false) }) {
                    Text("Cancelar", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            containerColor = OrionDarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
