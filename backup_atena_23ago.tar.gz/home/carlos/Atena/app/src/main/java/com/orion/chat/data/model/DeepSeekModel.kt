package com.orion.chat.data.model

enum class DeepSeekModel(val id: String, val displayName: String, val description: String, val supportsReasoning: Boolean) {
    DEEPSEEK_CHAT(
        id = "deepseek-chat",
        displayName = "DeepSeek V3",
        description = "Modelo principal balanceado, rápido e de alta capacidade para conversação geral.",
        supportsReasoning = false
    ),
    DEEPSEEK_REASONER(
        id = "deepseek-reasoner",
        displayName = "DeepSeek R1 (Reasoner)",
        description = "Modelo com cadeia de raciocínio passo a passo (CoT) para matemática, lógica e programação.",
        supportsReasoning = true
    ),
    QPANDA(
        id = "qpanda",
        displayName = "QPanda (Quantum)",
        description = "Interface de tradução e execução de algoritmos quânticos via SDK QPanda.",
        supportsReasoning = false
    );

    companion object {
        fun fromId(id: String): DeepSeekModel {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: DEEPSEEK_CHAT
        }
    }
}
