package com.orion.chat.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ApiMessage(
    @field:Json(name = "role") val role: String,
    @field:Json(name = "content") val content: String
)

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
    @field:Json(name = "model") val model: String,
    @field:Json(name = "messages") val messages: List<ApiMessage>,
    @field:Json(name = "stream") val stream: Boolean = true,
    @field:Json(name = "temperature") val temperature: Double? = 0.7,
    @field:Json(name = "max_tokens") val maxTokens: Int? = 4096
)

@JsonClass(generateAdapter = true)
data class ChatStreamChunk(
    @field:Json(name = "id") val id: String? = null,
    @field:Json(name = "object") val `object`: String? = null,
    @field:Json(name = "created") val created: Long? = null,
    @field:Json(name = "model") val model: String? = null,
    @field:Json(name = "choices") val choices: List<StreamChoice>? = null,
    @field:Json(name = "usage") val usage: StreamUsage? = null
)

@JsonClass(generateAdapter = true)
data class StreamChoice(
    @field:Json(name = "index") val index: Int? = 0,
    @field:Json(name = "delta") val delta: StreamDelta? = null,
    @field:Json(name = "finish_reason") val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class StreamDelta(
    @field:Json(name = "role") val role: String? = null,
    @field:Json(name = "content") val content: String? = null,
    @field:Json(name = "reasoning_content") val reasoningContent: String? = null
)

@JsonClass(generateAdapter = true)
data class StreamUsage(
    @field:Json(name = "prompt_tokens") val promptTokens: Int? = null,
    @field:Json(name = "completion_tokens") val completionTokens: Int? = null,
    @field:Json(name = "total_tokens") val totalTokens: Int? = null
)

@JsonClass(generateAdapter = true)
data class ApiErrorResponse(
    @field:Json(name = "error") val error: ApiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class ApiErrorDetail(
    @field:Json(name = "message") val message: String? = null,
    @field:Json(name = "type") val type: String? = null,
    @field:Json(name = "param") val param: String? = null,
    @field:Json(name = "code") val code: String? = null
)

sealed class StreamEvent {
    data class ContentDelta(val text: String) : StreamEvent()
    data class ReasoningDelta(val reasoningText: String) : StreamEvent()
    data class Completed(val finishReason: String?) : StreamEvent()
    data class Error(val throwable: Throwable) : StreamEvent()
}
