package com.orion.chat.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.ChatRole
import com.orion.chat.data.model.MessageStatus

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val role: String,
    val content: String,
    val reasoningContent: String?,
    val timestamp: Long,
    val status: String,
    val model: String?,
    val errorMessage: String?
) {
    fun toChatMessage(): ChatMessage {
        return ChatMessage(
            id = id,
            role = ChatRole.fromValue(role),
            content = content,
            reasoningContent = reasoningContent,
            timestamp = timestamp,
            status = try { MessageStatus.valueOf(status) } catch (e: Exception) { MessageStatus.SUCCESS },
            model = model,
            errorMessage = errorMessage
        )
    }

    companion object {
        fun fromChatMessage(msg: ChatMessage): ChatMessageEntity {
            return ChatMessageEntity(
                id = msg.id,
                role = msg.role.value,
                content = msg.content,
                reasoningContent = msg.reasoningContent,
                timestamp = msg.timestamp,
                status = msg.status.name,
                model = msg.model,
                errorMessage = msg.errorMessage
            )
        }
    }
}
