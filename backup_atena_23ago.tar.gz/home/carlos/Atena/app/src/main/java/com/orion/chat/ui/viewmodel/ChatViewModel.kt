package com.orion.chat.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.orion.chat.data.api.DeepSeekService
import com.orion.chat.data.local.ChatDatabase
import com.orion.chat.data.local.ChatPreferences
import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.ChatRole
import com.orion.chat.data.model.DeepSeekModel
import com.orion.chat.data.model.MessageStatus
import com.orion.chat.data.model.StreamEvent
import com.orion.chat.data.repository.ChatRepository
import com.orion.chat.ui.state.ChatUiState
import com.orion.chat.ui.state.StreamingState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(
    application: Application,
    private val repository: ChatRepository
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var streamingJob: Job? = null

    init {
        loadPreferences()
        observeMessages()
    }

    private fun loadPreferences() {
        val apiKey = repository.preferences.getApiKey()
        val modelId = repository.preferences.getSelectedModel()
        val systemPrompt = repository.preferences.getSystemPrompt()
        val temperature = repository.preferences.getTemperature()

        _uiState.update { current ->
            current.copy(
                apiKey = apiKey,
                isApiKeyConfigured = apiKey.isNotBlank(),
                selectedModel = DeepSeekModel.fromId(modelId),
                systemPrompt = systemPrompt,
                temperature = temperature
            )
        }
    }

    private fun observeMessages() {
        viewModelScope.launch {
            repository.messagesFlow.collect { messageList ->
                _uiState.update { current ->
                    current.copy(messages = messageList)
                }
            }
        }
    }

    fun onInputPromptChange(newPrompt: String) {
        _uiState.update { it.copy(inputPrompt = newPrompt) }
    }

    fun sendMessage(promptText: String? = null) {
        val prompt = (promptText ?: _uiState.value.inputPrompt).trim()
        if (prompt.isBlank()) return

        val currentApiKey = repository.preferences.getApiKey()
        if (currentApiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    showSettingsDialog = true,
                    streamingState = StreamingState.Error("Configure sua DEEPSEEK_API_KEY para iniciar as conversas.")
                )
            }
            return
        }

        // Cancel any active streaming before starting a new one
        streamingJob?.cancel()

        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = prompt,
            status = MessageStatus.SUCCESS,
            timestamp = System.currentTimeMillis()
        )

        val assistantMessageId = UUID.randomUUID().toString()
        val selectedModel = _uiState.value.selectedModel

        _uiState.update {
            it.copy(
                inputPrompt = "",
                streamingState = StreamingState.Loading,
                currentStreamingMessageId = assistantMessageId
            )
        }

        streamingJob = viewModelScope.launch(Dispatchers.IO) {
            // Save user message to database
            repository.saveMessage(userMessage)

            val contentBuffer = StringBuilder()
            val reasoningBuffer = StringBuilder()

            try {
                _uiState.update {
                    it.copy(streamingState = StreamingState.Streaming(partialContent = "", reasoningContent = null))
                }

                repository.streamChat(userPrompt = prompt, modelOverride = selectedModel.id)
                    .catch { throwable ->
                        throw throwable
                    }
                    .collect { event ->
                        when (event) {
                            is StreamEvent.ReasoningDelta -> {
                                reasoningBuffer.append(event.reasoningText)
                                _uiState.update { state ->
                                    state.copy(
                                        streamingState = StreamingState.Streaming(
                                            partialContent = contentBuffer.toString(),
                                            reasoningContent = reasoningBuffer.toString()
                                        )
                                    )
                                }
                            }
                            is StreamEvent.ContentDelta -> {
                                contentBuffer.append(event.text)
                                _uiState.update { state ->
                                    state.copy(
                                        streamingState = StreamingState.Streaming(
                                            partialContent = contentBuffer.toString(),
                                            reasoningContent = if (reasoningBuffer.isNotEmpty()) reasoningBuffer.toString() else null
                                        )
                                    )
                                }
                            }
                            is StreamEvent.Completed -> {
                                // Handled at end of flow
                            }
                            is StreamEvent.Error -> {
                                throw event.throwable
                            }
                        }
                    }

                // Streaming finished successfully - persist final response
                val finalAssistantMessage = ChatMessage(
                    id = assistantMessageId,
                    role = ChatRole.ASSISTANT,
                    content = contentBuffer.toString().ifBlank { "Sem resposta retornada pelo modelo." },
                    reasoningContent = if (reasoningBuffer.isNotEmpty()) reasoningBuffer.toString() else null,
                    timestamp = System.currentTimeMillis(),
                    status = MessageStatus.SUCCESS,
                    model = selectedModel.displayName
                )
                repository.saveMessage(finalAssistantMessage)

                _uiState.update {
                    it.copy(
                        streamingState = StreamingState.Success,
                        currentStreamingMessageId = null
                    )
                }
            } catch (cancellation: CancellationException) {
                // If user stopped stream mid-way, preserve whatever was generated
                if (contentBuffer.isNotEmpty() || reasoningBuffer.isNotEmpty()) {
                    val stoppedMessage = ChatMessage(
                        id = assistantMessageId,
                        role = ChatRole.ASSISTANT,
                        content = contentBuffer.toString() + " [Interrompido pelo usuário]",
                        reasoningContent = if (reasoningBuffer.isNotEmpty()) reasoningBuffer.toString() else null,
                        timestamp = System.currentTimeMillis(),
                        status = MessageStatus.SUCCESS,
                        model = selectedModel.displayName
                    )
                    repository.saveMessage(stoppedMessage)
                }
                _uiState.update {
                    it.copy(
                        streamingState = StreamingState.Idle,
                        currentStreamingMessageId = null
                    )
                }
            } catch (e: Exception) {
                val errorMessage = e.message ?: "Erro de conexão ao comunicar com a DeepSeek."
                val errorAssistantMessage = ChatMessage(
                    id = assistantMessageId,
                    role = ChatRole.ASSISTANT,
                    content = if (contentBuffer.isNotEmpty()) contentBuffer.toString() else "",
                    reasoningContent = if (reasoningBuffer.isNotEmpty()) reasoningBuffer.toString() else null,
                    timestamp = System.currentTimeMillis(),
                    status = MessageStatus.ERROR,
                    model = selectedModel.displayName,
                    errorMessage = errorMessage
                )
                repository.saveMessage(errorAssistantMessage)

                _uiState.update {
                    it.copy(
                        streamingState = StreamingState.Error(errorMessage),
                        currentStreamingMessageId = null
                    )
                }
            }
        }
    }

    fun stopStreaming() {
        streamingJob?.cancel()
        streamingJob = null
        _uiState.update {
            it.copy(
                streamingState = StreamingState.Idle,
                currentStreamingMessageId = null
            )
        }
    }

    fun retryLastMessage() {
        val lastUserMessage = _uiState.value.messages.lastOrNull { it.role == ChatRole.USER }
        if (lastUserMessage != null) {
            sendMessage(lastUserMessage.content)
        }
    }

    fun clearChat() {
        streamingJob?.cancel()
        viewModelScope.launch {
            repository.clearHistory()
            _uiState.update {
                it.copy(
                    messages = emptyList(),
                    streamingState = StreamingState.Idle,
                    currentStreamingMessageId = null,
                    showClearConfirmDialog = false
                )
            }
        }
    }

    fun deleteMessage(id: String) {
        viewModelScope.launch {
            repository.deleteMessage(id)
        }
    }

    fun setApiKey(apiKey: String) {
        repository.preferences.setApiKey(apiKey)
        _uiState.update {
            it.copy(
                apiKey = apiKey.trim(),
                isApiKeyConfigured = apiKey.trim().isNotBlank()
            )
        }
    }

    fun setSelectedModel(model: DeepSeekModel) {
        repository.preferences.setSelectedModel(model.id)
        _uiState.update { it.copy(selectedModel = model) }
    }

    fun setTemperature(temp: Float) {
        repository.preferences.setTemperature(temp)
        _uiState.update { it.copy(temperature = temp) }
    }

    fun setSystemPrompt(prompt: String) {
        repository.preferences.setSystemPrompt(prompt)
        _uiState.update { it.copy(systemPrompt = prompt) }
    }

    fun setShowSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun setShowClearConfirmDialog(show: Boolean) {
        _uiState.update { it.copy(showClearConfirmDialog = show) }
    }

    fun dismissError() {
        if (_uiState.value.streamingState is StreamingState.Error) {
            _uiState.update { it.copy(streamingState = StreamingState.Idle) }
        }
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val apiService = DeepSeekService()
            val database = ChatDatabase.getInstance(application)
            val preferences = ChatPreferences(application)
            val repository = ChatRepository(apiService, database.chatDao(), preferences)
            return ChatViewModel(application, repository) as T
        }
    }
}
