package com.orion.chat.ui.state

import com.orion.chat.data.model.ChatMessage
import com.orion.chat.data.model.DeepSeekModel

sealed interface StreamingState {
    data object Idle : StreamingState
    data object Loading : StreamingState
    data class Streaming(
        val partialContent: String = "",
        val reasoningContent: String? = null
    ) : StreamingState
    data object Success : StreamingState
    data class Error(
        val message: String,
        val canRetry: Boolean = true
    ) : StreamingState
}

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputPrompt: String = "",
    val streamingState: StreamingState = StreamingState.Idle,
    val selectedModel: DeepSeekModel = DeepSeekModel.DEEPSEEK_CHAT,
    val apiKey: String = "",
    val isApiKeyConfigured: Boolean = false,
    val showSettingsDialog: Boolean = false,
    val showClearConfirmDialog: Boolean = false,
    val systemPrompt: String = "",
    val temperature: Float = 0.7f,
    val currentStreamingMessageId: String? = null
) {
    val isStreaming: Boolean
        get() = streamingState is StreamingState.Streaming || streamingState is StreamingState.Loading
}
