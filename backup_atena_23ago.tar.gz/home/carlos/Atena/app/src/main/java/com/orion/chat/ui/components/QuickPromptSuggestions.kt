package com.orion.chat.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orion.chat.ui.theme.AtenaCyanPrimary
import com.orion.chat.ui.theme.AtenaIndigo
import com.orion.chat.ui.theme.AtenaViolet
import com.orion.chat.ui.theme.OrionDarkBorder
import com.orion.chat.ui.theme.OrionDarkSurfaceVariant

data class QuickPrompt(
    val title: String,
    val prompt: String,
    val icon: ImageVector
)

val DEFAULT_QUICK_PROMPTS = listOf(
    QuickPrompt(
        title = "Projeto Orion",
        prompt = "Explique a visão e objetivos do Projeto Orion e como a IA Atena atua como copiloto.",
        icon = Icons.Default.RocketLaunch
    ),
    QuickPrompt(
        title = "Raciocínio & Lógica",
        prompt = "Resolva este desafio lógico passo a passo: Se 5 máquinas levam 5 minutos para fazer 5 peças, quanto tempo levam 100 máquinas para fazer 100 peças?",
        icon = Icons.Default.Psychology
    ),
    QuickPrompt(
        title = "Kotlin & Flow",
        prompt = "Como funciona o consumo de Server-Sent Events (SSE) usando Flow e OkHttp no Android Kotlin?",
        icon = Icons.Default.Code
    ),
    QuickPrompt(
        title = "Ideias Criativas",
        prompt = "Me dê 3 ideias inovadoras de arquitetura para assistentes de IA nativos em dispositivos móveis.",
        icon = Icons.Default.TipsAndUpdates
    )
)

@Composable
fun EmptyChatHero(
    onSelectPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing Atena Orb
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(AtenaCyanPrimary, AtenaIndigo, AtenaViolet)
                    ),
                    shape = CircleShape
                )
                .border(2.dp, AtenaCyanPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Atena Orion",
                tint = Color.White,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Atena • Projeto Orion",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Assistente de inteligência artificial com respostas em tempo real via DeepSeek",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "Sugestões de início rápido:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = AtenaCyanPrimary,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            for (item in DEFAULT_QUICK_PROMPTS) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = OrionDarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, OrionDarkBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectPrompt(item.prompt) }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = AtenaCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
                                color = Color.White
                            )
                            Text(
                                text = item.prompt,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
