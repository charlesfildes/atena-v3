package com.orion.chat.ui.theme

import androidx.compose.ui.graphics.Color

// Orion Cosmic Palette
val OrionDarkBackground = Color(0xFF0B0E14)
val OrionDarkSurface = Color(0xFF121722)
val OrionDarkSurfaceVariant = Color(0xFF1C2230)
val OrionDarkBorder = Color(0xFF263044)

// Atena Neon & Accent Colors
val AtenaCyanPrimary = Color(0xFF00D4FF)
val AtenaCyanSecondary = Color(0xFF38E1FF)
val AtenaIndigo = Color(0xFF6366F1)
val AtenaViolet = Color(0xFF8B5CF6)
val AtenaDeepBlue = Color(0xFF0A2540)

// User & Assistant Chat Bubbles
val UserBubbleBackground = Color(0xFF1E293B)
val UserBubbleBorder = Color(0xFF334155)
val AssistantBubbleBackground = Color(0xFF111827)
val AssistantBubbleBorder = Color(0xFF1F2937)
val ReasoningBackground = Color(0xFF0F172A)

// Text & Status
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

val StatusSuccess = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)
val StatusStreaming = Color(0xFF00D4FF)

// Light Palette (for dynamic / light mode fallback)
val OrionLightBackground = Color(0xFFF8FAFC)
val OrionLightSurface = Color(0xFFFFFFFF)
val OrionLightSurfaceVariant = Color(0xFFF1F5F9)
val OrionLightBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val UserBubbleLight = Color(0xFFE0F2FE)
val AssistantBubbleLight = Color(0xFFFFFFFF)
