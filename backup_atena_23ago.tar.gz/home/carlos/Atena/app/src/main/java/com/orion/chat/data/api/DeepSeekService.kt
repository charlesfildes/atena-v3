package com.orion.chat.data.api

import android.util.Log
import com.orion.chat.data.model.ChatCompletionRequest
import com.orion.chat.data.model.ChatStreamChunk
import com.orion.chat.data.model.StreamEvent
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.IOException
import java.util.concurrent.TimeUnit

class DeepSeekService {

    companion object {
        private const val TAG = "DeepSeekService"
        const val DEFAULT_BASE_URL = "https://orion-backend-git-487033451365.europe-west1.run.app/api/chat"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val requestAdapter = moshi.adapter(ChatCompletionRequest::class.java)
    private val chunkAdapter = moshi.adapter(ChatStreamChunk::class.java)

    fun streamChatCompletion(
        apiKey: String,
        requestBody: ChatCompletionRequest,
        baseUrl: String = DEFAULT_BASE_URL
    ): Flow<StreamEvent> = callbackFlow {
        val jsonBody = requestAdapter.toJson(requestBody)
        val body = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

        val httpRequest = Request.Builder()
            .url(baseUrl)
            .addHeader("x-deepseek-api-key", apiKey.trim())
            .addHeader("Accept", "text/event-stream")
            .post(body)
            .build()

        val call = client.newCall(httpRequest)

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Falha na requisição: ${e.message}", e)
                trySend(StreamEvent.Error(e))
                close(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    val errorStr = response.body?.string() ?: "Erro desconhecido"
                    Log.e(TAG, "Erro no servidor Orion (${response.code}): $errorStr")
                    val err = IOException("Erro no servidor Orion (${response.code}): $errorStr")
                    trySend(StreamEvent.Error(err))
                    close(err)
                    return
                }

                val responseBody = response.body
                if (responseBody == null) {
                    val err = IOException("Resposta do servidor veio vazia")
                    trySend(StreamEvent.Error(err))
                    close(err)
                    return
                }

                try {
                    val reader = BufferedReader(InputStreamReader(responseBody.byteStream()))
                    var line: String?

                    while (reader.readLine().also { line = it } != null) {
                        val currentLine = line?.trim() ?: continue
                        if (currentLine.isEmpty() || currentLine.startsWith(":")) continue

                        if (currentLine.startsWith("data: ")) {
                            val data = currentLine.substring(6).trim()
                            if (data == "[DONE]") {
                                trySend(StreamEvent.Completed(null))
                                break
                            }

                            try {
                                val chunk = chunkAdapter.fromJson(data)
                                val choice = chunk?.choices?.firstOrNull()
                                val delta = choice?.delta

                                // Reasoning content (ex: DeepSeek R1)
                                if (!delta?.reasoningContent.isNullOrEmpty()) {
                                    trySend(StreamEvent.ReasoningDelta(delta!!.reasoningContent!!))
                                }

                                // Texto principal
                                if (!delta?.content.isNullOrEmpty()) {
                                    trySend(StreamEvent.ContentDelta(delta!!.content!!))
                                }

                                if (choice?.finishReason != null) {
                                    trySend(StreamEvent.Completed(choice.finishReason))
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "Falha ao deserializar chunk SSE: $data", e)
                            }
                        }
                    }
                    close()
                } catch (e: Exception) {
                    Log.e(TAG, "Erro na leitura do fluxo SSE", e)
                    trySend(StreamEvent.Error(e))
                    close(e)
                } finally {
                    response.close()
                }
            }
        })

        awaitClose {
            call.cancel()
        }
    }
}
