package com.orion.chat.data.model

enum class ChatRole(val value: String) {
    USER("user"),
    ASSISTANT("assistant"),
    SYSTEM("system");

    companion object {
        fun fromValue(value: String): ChatRole {
            return entries.firstOrNull { it.value.equals(value, ignoreCase = true) } ?: USER
        }
    }
}

enum class MessageStatus {
    IDLE,
    SENDING,
    STREAMING,
    SUCCESS,
    ERROR
}
