package com.orion.chat.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.orion.chat.data.model.DeepSeekModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ChatPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _apiKeyFlow = MutableStateFlow(getApiKey())
    val apiKeyFlow: StateFlow<String> = _apiKeyFlow.asStateFlow()

    private val _modelFlow = MutableStateFlow(getSelectedModel())
    val modelFlow: StateFlow<String> = _modelFlow.asStateFlow()

    private val _systemPromptFlow = MutableStateFlow(getSystemPrompt())
    val systemPromptFlow: StateFlow<String> = _systemPromptFlow.asStateFlow()

    private val _temperatureFlow = MutableStateFlow(getTemperature())
    val temperatureFlow: StateFlow<Float> = _temperatureFlow.asStateFlow()

    fun getApiKey(): String {
        val savedKey = prefs.getString(KEY_API_KEY, null)
        if (!savedKey.isNullOrBlank()) {
            return savedKey
        }
        // Fallback to BuildConfig if provided at build time
        return try {
            val buildKey = BuildConfig.DEEPSEEK_API_KEY
            if (buildKey.isNotBlank() && buildKey != "MY_DEEPSEEK_API_KEY") buildKey else ""
        } catch (e: Throwable) {
            ""
        }
    }

    fun setApiKey(apiKey: String) {
        prefs.edit().putString(KEY_API_KEY, apiKey.trim()).apply()
        _apiKeyFlow.value = apiKey.trim()
    }

    fun getSelectedModel(): String {
        return prefs.getString(KEY_MODEL, DeepSeekModel.DEEPSEEK_CHAT.id) ?: DeepSeekModel.DEEPSEEK_CHAT.id
    }

    fun setSelectedModel(modelId: String) {
        prefs.edit().putString(KEY_MODEL, modelId).apply()
        _modelFlow.value = modelId
    }

    fun getSystemPrompt(): String {
        return prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
    }

    fun setSystemPrompt(prompt: String) {
        prefs.edit().putString(KEY_SYSTEM_PROMPT, prompt).apply()
        _systemPromptFlow.value = prompt
    }

    fun getTemperature(): Float {
        return prefs.getFloat(KEY_TEMPERATURE, 0.7f)
    }

    fun setTemperature(temp: Float) {
        prefs.edit().putFloat(KEY_TEMPERATURE, temp).apply()
        _temperatureFlow.value = temp
    }

    companion object {
        private const val PREFS_NAME = "orion_atena_chat_prefs"
        private const val KEY_API_KEY = "deepseek_api_key"
        private const val KEY_MODEL = "deepseek_model"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_TEMPERATURE = "temperature"

        const val DEFAULT_SYSTEM_PROMPT =
            "Você é a Atena, assistente de inteligência artificial de elite do Projeto Orion. " +
            "Responda de maneira perspicaz, elegante, precisa e direta, utilizando markdown para estruturar códigos, listas e conceitos-chave."
    }
}
