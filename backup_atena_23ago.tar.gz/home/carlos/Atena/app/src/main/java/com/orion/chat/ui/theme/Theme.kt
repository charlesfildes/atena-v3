package com.orion.chat.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val OrionDarkColorScheme = darkColorScheme(
    primary = AtenaCyanPrimary,
    onPrimary = Color(0xFF003642),
    primaryContainer = Color(0xFF004E5F),
    onPrimaryContainer = Color(0xFFBCE9FF),
    secondary = AtenaIndigo,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2C3E6B),
    onSecondaryContainer = Color(0xFFD6E3FF),
    tertiary = AtenaViolet,
    onTertiary = Color.White,
    background = OrionDarkBackground,
    onBackground = TextPrimaryDark,
    surface = OrionDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = OrionDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = OrionDarkBorder,
    error = StatusError,
    onError = Color.White
)

private val OrionLightColorScheme = lightColorScheme(
    primary = Color(0xFF00687A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBCE9FF),
    onPrimaryContainer = Color(0xFF001F26),
    secondary = Color(0xFF4355B9),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDEE0FF),
    onSecondaryContainer = Color(0xFF00115A),
    tertiary = Color(0xFF6B4EA2),
    onTertiary = Color.White,
    background = OrionLightBackground,
    onBackground = TextPrimaryLight,
    surface = OrionLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = OrionLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = OrionLightBorder,
    error = StatusError,
    onError = Color.White
)

@Composable
fun OrionAtenaTheme(
    darkTheme: Boolean = true, // Default to Orion cosmic dark theme for immersive experience
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> OrionDarkColorScheme
        else -> OrionLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
